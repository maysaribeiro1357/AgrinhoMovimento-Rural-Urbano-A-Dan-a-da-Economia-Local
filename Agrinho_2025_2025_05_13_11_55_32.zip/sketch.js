let buildings = [];
let farms = [];
let trucks = [];
let markets = [];
let workers = [];
let clouds = [];

function setup() {
  createCanvas(600, 400);

 
  for (let i = 0; i < 3; i++) {
    farms.push(new Farm(50 + i * 150, 250));
  }


  for (let i = 0; i < 5; i++) {
    buildings.push(new Building(350 + i * 50, 100));
  }

 
  for (let i = 0; i < 2; i++) {
    markets.push(new Market(300 + i * 100, 220));
  }

  for (let i = 0; i < 4; i++) {
    workers.push(new Worker(100 + i * 120, 270));
  }


  for (let i = 0; i < 3; i++) {
    trucks.push(new Truck(50 + i * 150, 330));
  }

  for (let i = 0; i < 3; i++) {
    clouds.push(new Cloud(random(width), random(50, 120)));
  }
}

function draw() {
  background(135, 206, 250); 

  drawRoad(); 

  
  for (let farm of farms) {
    farm.show();
  }


  for (let building of buildings) {
    building.show();
  }

  
  for (let market of markets) {
    market.show();
  }

 
  for (let worker of workers) {
    worker.show();
  }

  for (let truck of trucks) {
    truck.move();
    truck.show();
  }

 
  for (let cloud of clouds) {
    cloud.move();
    cloud.show();
  }
}

function drawRoad() {
  fill(50);
  rect(0, 320, width, 60);
}

class Farm {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  
  show() {
    fill(34, 139, 34);
    rect(this.x, this.y, 60, 60);
  }
}

class Building {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  
  show() {
    fill(100);
    rect(this.x, this.y, 40, 100);
  }
}

class Market {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  
  show() {
    fill(255, 215, 0);
    rect(this.x, this.y, 50, 70);
  }
}

class Worker {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  
  show() {
    fill(255, 0, 0);
    ellipse(this.x, this.y, 20, 20);
    fill(0);
    rect(this.x - 5, this.y + 10, 10, 20);
  }
}

class Truck {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.speed = random(1, 2);
  }
  
  move() {
    this.x += this.speed;
    if (this.x > width) {
      this.x = 0;
    }
  }
  
  show() {
    fill(255, 165, 0);
    rect(this.x, this.y, 40, 20);
    fill(0);
    ellipse(this.x + 5, this.y + 20, 10, 10);
    ellipse(this.x + 35, this.y + 20, 10, 10);
  }
}

class Cloud {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.speed = 0.5;
  }
  
  move() {
    this.x += this.speed;
    if (this.x > width) {
      this.x = 0;
    }
  }
  
  show() {
    fill(255);
    ellipse(this.x, this.y, 40, 30);
    ellipse(this.x + 20, this.y, 50, 40);
    ellipse(this.x - 20, this.y, 50, 40);
  }
}
